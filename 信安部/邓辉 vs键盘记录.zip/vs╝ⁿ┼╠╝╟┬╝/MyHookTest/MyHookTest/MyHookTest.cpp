#include<Windows.h>
#include "resource.h"

#pragma comment(lib,"Dll.lib")

_declspec(dllimport) void SetHook();
_declspec(dllimport) void UnHook();

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,PSTR szCmdLine,int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("���̼�¼") ;
     HWND         hwnd ;
     MSG          msg ;
     WNDCLASS     wndclass ;
     
     wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     wndclass.lpfnWndProc   = WndProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE (IDI_ICON1));
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;
     wndclass.lpszMenuName  = NULL ;
     wndclass.lpszClassName = szAppName ;
          
     if (!RegisterClass (&wndclass))
     {
          MessageBox (NULL, TEXT ("Program requires Windows NT!"), 
                      szAppName, MB_ICONERROR) ;
          return 0 ;
     }
     
     hwnd = CreateWindow (szAppName, TEXT ("���̼�¼"),
                          WS_OVERLAPPEDWINDOW,
                          120, 120,
                          265, 185,
                          NULL, NULL, hInstance, NULL) ;
     
     ShowWindow (hwnd, iCmdShow) ;
     UpdateWindow (hwnd) ;
     
     while (GetMessage (&msg, NULL, 0, 0))
     {
          TranslateMessage (&msg) ;
          DispatchMessage (&msg) ;
     }
     return msg.wParam ;
}
LRESULT CALLBACK WndProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	static HICON hIcon;
	HINSTANCE hInstance;
	static int cxClient,cyClient,cxIcon,cyIcon,cxBitmap,cyBitmap;
	HDC hdc,hdcMen;
	PAINTSTRUCT ps;
	BITMAP bitmap;
	static HBITMAP hBitmap;
	switch(message)
	{
	case WM_CREATE:
		hInstance=((LPCREATESTRUCT)lParam)->hInstance;
		hIcon=LoadIcon(hInstance, MAKEINTRESOURCE (IDI_ICON1));
		hBitmap=LoadBitmap(hInstance,  MAKEINTRESOURCE(Bitmap));
		/*hBitmap=(HBITMAP)LoadImage(NULL,TEXT("Bitmap"),
                  IMAGE_BITMAP,0,0,
                  LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);*/
		if(hBitmap==NULL)
			MessageBox(NULL,TEXT("BITMAP"),TEXT("MY"),MB_OK);
		GetObject(hBitmap,sizeof(BITMAP),&bitmap);
		cxBitmap=bitmap.bmWidth;
		cyBitmap=bitmap.bmHeight;
		cxIcon=GetSystemMetrics(SM_CXICON);
		cyIcon=GetSystemMetrics(SM_CYICON);
		SetHook();
		return 0;
	case WM_SIZE:
		cxClient=LOWORD(lParam);
		cyClient=LOWORD(lParam);
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hwnd,&ps);
		hdcMen=CreateCompatibleDC(hdc);
		SelectObject(hdcMen,hBitmap);
		
		BitBlt(hdc,0,0,cxBitmap,cyBitmap,hdcMen,0,0,SRCCOPY);
		//DrawIcon(hdc,80-cxIcon/2,80-cyIcon,hIcon);

		DeleteDC(hdcMen);
		EndPaint(hwnd,&ps);
		return 0;
	case WM_DESTROY:
		UnHook();
		DeleteObject(hBitmap);
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc (hwnd, message, wParam, lParam);
	//return 0;
}