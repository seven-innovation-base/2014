#ifdef DLL_API
#else
#define DLL_API extern "C" _declspec(dllimport)
#endif

DLL_API void SetHook();
DLL_API void UnHook();